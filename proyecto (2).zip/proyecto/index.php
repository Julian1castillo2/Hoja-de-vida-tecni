<?php
// ========== CONFIGURACIÓN DE LA BASE DE DATOS ==========
$servidor = "localhost";    // Servidor local de MySQL
$usuario = "root";          // Usuario por defecto de XAMPP
$clave = "";                // Contraseña vacía por defecto
$baseDeDatos = "datos";     // Nombre de la base de datos

// Establecer conexión con la base de datos
$enlace = mysqli_connect($servidor, $usuario, $clave, $baseDeDatos);
if (!$enlace) {
    die("Error de conexión: " . mysqli_connect_error());
}

// ========== INICIALIZACIÓN DE VARIABLES ==========
$mensaje = "";        // Mensaje para mostrar al usuario
$qrFile = "";         // Ruta del archivo QR generado
$pdfUrl = "";         // URL del PDF generado
$fecha = "";          // Fecha del mantenimiento
$numero = "";         // Número de la máquina
$tecnico = "";        // Nombre del técnico
$repuestos = "";      // Repuestos utilizados
$mantenimiento = "";  // Descripción del mantenimiento

// ========== PROCESAMIENTO DEL FORMULARIO ==========
if (isset($_POST['registro'])) {
    // Sanitizar datos recibidos del formulario para evitar XSS
    $fecha = htmlspecialchars($_POST['fecha'] ?? '');
    $numero = htmlspecialchars($_POST['numero'] ?? '');
    $tecnico = htmlspecialchars($_POST['tecnico'] ?? '');
    $repuestos = htmlspecialchars($_POST['repuestos'] ?? '');
    $mantenimiento = htmlspecialchars($_POST['mantenimiento'] ?? '');

    // Validar que los campos obligatorios no estén vacíos
    if (!empty($fecha) && !empty($numero) && !empty($tecnico)) {
        // Preparar consulta SQL segura (evita inyección SQL)
        $insertarDatos = "INSERT INTO tecni (fecha, numero, tecnico, repuestos, mantenimiento) 
                         VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($enlace, $insertarDatos);
        mysqli_stmt_bind_param($stmt, "sssss", $fecha, $numero, $tecnico, $repuestos, $mantenimiento);

        // Ejecutar la consulta
        if (mysqli_stmt_execute($stmt)) {
            $last_id = mysqli_insert_id($enlace); // ID del último registro insertado

            // ========== GENERACIÓN DEL PDF ==========
            if (file_exists('fpdf/fpdf.php')) {
                require('fpdf/fpdf.php');
                // Crear directorio para PDFs si no existe
                if (!file_exists('pdfs')) {
                    mkdir('pdfs', 0777, true);
                }
                // Crear el PDF con los datos del registro
                $pdfFile = "pdfs/registro_$last_id.pdf";
                $pdf = new FPDF();
                $pdf->AddPage();
                $pdf->SetFont('Arial','B',16);
                $pdf->Cell(0,10,'Registro de Mantenimiento',0,1,'C');
                $pdf->SetFont('Arial','',12);
                $pdf->Ln(10);
                $pdf->Cell(0,10,"ID: $last_id",0,1);
                $pdf->Cell(0,10,"Fecha: $fecha",0,1);
                $pdf->Cell(0,10,"Numero: $numero",0,1);
                $pdf->Cell(0,10,"Tecnico: $tecnico",0,1);
                $pdf->Cell(0,10,"Repuestos: $repuestos",0,1);
                $pdf->MultiCell(0,10,"Mantenimiento: $mantenimiento");
                $pdf->Output('F', $pdfFile);

                // ========== GENERACIÓN DEL QR ==========
                if (file_exists('phpqrcode/qrlib.php')) {
                    include "phpqrcode/qrlib.php";
                    // Crear directorio para QRs si no existe
                    if (!file_exists('qrs')) {
                        mkdir('qrs', 0777, true);
                    }
                    // Definir constante necesaria para la librería QR
                    if (!defined('QR_ECLEVEL_L')) {
                        define('QR_ECLEVEL_L', 0);
                    }
                    // Generar la URL del PDF y el código QR
                    $pdfUrl = "http://192.168.100.83/proyecto/$pdfFile";
                    $qrFile = "qrs/registro_$last_id.png";
                    QRcode::png($pdfUrl, $qrFile, QR_ECLEVEL_L, 4);
                    $mensaje = "Registro exitoso. Código QR generado (abre el PDF):";
                }
            }
        }
        mysqli_stmt_close($stmt);
    } else {
        $mensaje = "Por favor, complete todos los campos requeridos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Hoja de Vida Máquinas - Tecnimontacargas</title>
  <style>
    /* ========== VARIABLES DE COLOR ========== */
    :root {
      --primary-yellow: #FFD700;
      --secondary-gray: #404040;
      --light-gray: #f5f5f5;
      --dark-gray: #333333;
    }

    /* ========== ESTILOS GENERALES DE LA PÁGINA ========== */
    body {
      background: var(--light-gray);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 20px;
      min-height: 100vh;
    }

    .container {
      max-width: 800px;
      margin: 0 auto;
    }

    /* ========== CABECERA ========== */
    .header {
      background: var(--secondary-gray); /* Fondo gris oscuro */
      color: var(--primary-yellow);      /* Texto amarillo */
      padding: 20px;
      border-radius: 10px 10px 0 0;
      text-align: center;
      margin-bottom: 2rem;
    }

    .company-name {
      font-size: 2.5rem;
      margin: 0;
      text-transform: uppercase;
      letter-spacing: 2px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }

    .form-title {
      font-size: 1.8rem;
      color: white; /* Letra blanca para el título */
      margin: 0;
      padding: 10px 0;
    }

    /* ========== FORMULARIO ========== */
    form {
      background: #ffffff;
      padding: 2rem;
      border-radius: 10px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      border: 2px solid var(--primary-yellow);
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    label {
      display: block;
      color: var(--secondary-gray);
      margin-bottom: 0.5rem;
      font-weight: bold;
    }

    input[type="text"],
    input[type="date"],
    textarea {
      width: 100%;
      padding: 0.75rem;
      border: 2px solid var(--light-gray);
      border-radius: 5px;
      box-sizing: border-box;
      transition: border-color 0.3s ease;
    }

    input[type="text"]:focus,
    input[type="date"]:focus,
    textarea:focus {
      outline: none;
      border-color: var(--primary-yellow);
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    .button-group {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }

    input[type="submit"],
    input[type="reset"] {
      flex: 1;
      padding: 1rem;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
      transition: all 0.3s ease;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    input[type="submit"] {
      background: var(--primary-yellow);
      color: var(--secondary-gray);
    }

    input[type="reset"] {
      background: var(--secondary-gray);
      color: white;
    }

    input[type="submit"]:hover {
      background: #ffc400;
      transform: translateY(-2px);
    }

    input[type="reset"]:hover {
      background: #333;
      transform: translateY(-2px);
    }

    .mensaje {
      text-align: center;
      margin-top: 1rem;
      padding: 1rem;
      border-radius: 5px;
      background: var(--light-gray);
      color: var(--secondary-gray);
    }

    .qr-container {
      margin-top: 2rem;
      text-align: center;
    }

    .qr-img {
      max-width: 200px;
      padding: 15px;
      background: white;
      border: 2px solid var(--primary-yellow);
      border-radius: 10px;
    }

    .pdf-link {
      margin-top: 1rem;
    }

    .pdf-link a {
      color: var(--secondary-gray);
      text-decoration: none;
      font-weight: bold;
      transition: color 0.3s ease;
    }

    .pdf-link a:hover {
      color: var(--primary-yellow);
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- CABECERA CON NOMBRE DE LA EMPRESA Y TÍTULO -->
    <div class="header">
      <h1 class="company-name">Tecnimontacargas</h1>
      <h2 class="form-title">Hoja de Vida Máquinas</h2>
    </div>

    <!-- FORMULARIO DE REGISTRO -->
    <form action="#" method="post">
      <div class="form-group">
        <label for="fecha">Fecha</label>
        <input type="date" name="fecha" id="fecha" required>
      </div>

      <div class="form-group">
        <label for="numero">Número de Máquina</label>
        <input type="text" name="numero" id="numero" required>
      </div>

      <div class="form-group">
        <label for="tecnico">Técnico Responsable</label>
        <input type="text" name="tecnico" id="tecnico" required>
      </div>

      <div class="form-group">
        <label for="repuestos">Repuestos Utilizados</label>
        <input type="text" name="repuestos" id="repuestos" required>
      </div>

      <div class="form-group">
        <label for="mantenimiento">Descripción del Mantenimiento</label>
        <textarea name="mantenimiento" id="mantenimiento" required></textarea>
      </div>

      <div class="button-group">
        <input type="submit" name="registro" value="Registrar">
        <input type="reset" value="Limpiar">
      </div>

      <!-- MENSAJE Y QR/PDF SI EXISTEN -->
      <?php if ($mensaje): ?>
        <div class="mensaje"><?php echo $mensaje; ?></div>
        <?php if ($qrFile): ?>
          <div class="qr-container">
            <img src="<?php echo $qrFile; ?>" alt="Código QR" class="qr-img">
            <div class="pdf-link">
              <a href="<?php echo $pdfUrl; ?>" target="_blank">Abrir PDF generado</a>
            </div>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </form>
  </div>
</body>
</html>